package com.example.restservice;

import org.springframework 
	.stereotype 
	.Repository; 

// Importing the employees class to 
// use the defined properties 
// in this class 
import com.example.restservice.Employees; 

@Repository

public class EmployeeManager { 

	private static Employees list 
		= new Employees(); 

	static
	{ 

		list.getEmployeeList().add( 
			new Employee( 
				"73618", 
				"Prem", 
				"Tiwari", 
				"chapradreams@gmail.com",
				"Sr coder")); 

		list.getEmployeeList().add( 
			new Employee( 
				"21334", "Vikash", 
				"Kumar", 
				"abc@gmail.com",
				"Jr coder")); 

		list.getEmployeeList().add( 
			new Employee( 
				"63956", "Ritesh", 
				"Ojha", 
				"asdjf@gmail.com",
				"Sr coder")); 

		  
	} 

	public Employees getAllEmployees() 
	{ 

		return list; 
	} 
	public void addEmployee(Employee employee) 
	{ 
		list.getEmployeeList() 
			.add(employee); 
		  
	} 
} 

